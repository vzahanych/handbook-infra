# Project 2 — Distributed time-series query backend (Go)

> **Dimension:** distributed-systems correctness and reliability — sharding,
> consistency trade-offs, SLOs, and a concrete incident/MTTR win. **Map this
> onto:** any distributed Go system you worked on where data was partitioned
> across nodes and queries had to be correct, bounded, and fast under load.
> Replace `[bracketed]` values with real numbers.

---

## The 30-second version (lead with this)

> "I worked on the query side of a distributed time-series system — `[PromQL /
> a query API]` over data sharded across `[N]` nodes. The challenge was returning
> correct, bounded-latency answers when the data for one query lives on many
> nodes and any node can be slow or down. I designed the scatter-gather query
> path with per-node deadlines and partial-result handling, and led the rollout
> of distributed tracing across the services, which together took p99 query
> latency from `[A s]` to `[B s]` and cut incident MTTR from `[H]` to `[L]`."

---

## Context

The system stored `[metrics / traces / events]` partitioned by `[series key /
tenant + time]` across a horizontally scaled fleet, and exposed a query layer
that dashboards and alerts hammered continuously. Because alerting sat on top of
it, a slow or wrong query didn't just annoy a user — it could **mask a real
production incident** or fire a false alert, so correctness and tail latency were
the product, not a nice-to-have.

## The problem / constraint

A single query fans out to every shard that might hold matching data, and the
overall latency is governed by the **slowest** shard — the tail-latency
amplification problem that gets worse as you add nodes. Three constraints
collided: queries had to be **bounded** (a heavy query must not run forever and
exhaust memory), **correct under partial failure** (one dead shard shouldn't
make the whole answer silently wrong), and **fair** across tenants sharing the
fleet. The hard design question was what to do when not every shard answers in
time.

## My role and the key decisions

I owned the distributed query path and drove the observability rollout that made
it debuggable. The decisions, as trade-offs:

- **Scatter-gather with per-node deadlines.** The coordinator fans the query out
  with a budget, and a slow shard is cut at its deadline rather than allowed to
  drag the whole request. The trade-off — and the part interviewers probe — is
  **partial results vs. failing the query**: I made it explicit and *labeled*,
  so a response says "computed from `[k of N]` shards" instead of quietly
  returning a wrong number. For alerting paths I made that degradation a
  first-class, visible state.
- **Bounded execution to protect the cluster.** I added per-query limits — max
  series touched, max memory, max time range scanned — so one pathological
  dashboard query can't OOM a coordinator. This is the query-side analogue of
  backpressure: protect the shared system from any single caller.
- **Streaming aggregation over materializing.** Rather than pull all matching
  series to the coordinator and then aggregate, I pushed partial aggregation to
  the shards and streamed/merged results, which bounds coordinator memory and is
  the only thing that makes high-fan-out queries viable. Trade-off: more complex
  merge logic for far less memory.
- **Consistency stance, stated deliberately.** For this telemetry workload I
  chose `[availability and bounded staleness]` over strict consistency — a query
  may miss the last `[few seconds]` of in-flight data, which is the right call
  for monitoring and which I can defend against "why not strongly consistent?"
- **Distributed tracing as the debugging substrate.** The decisive reliability
  win: I instrumented the services with `[OpenTelemetry]` so a slow query could
  be followed across coordinator and shards to the exact slow hop. Before this,
  diagnosing a latency regression meant correlating logs by hand across nodes;
  after, it was one trace.

## Impact

- p99 query latency `[A s] → [B s]`; the long tail from single slow shards
  largely disappeared once deadlines + partial results were in.
- **Incident MTTR `[H] → [L]`** — the tracing rollout is the line I'd quote
  loudest, because it's the most Dash0-shaped result: faster root-cause via
  correlated traces.
- `[N]` classes of "silently wrong answer" eliminated by making partial results
  explicit and labeled.
- Cluster stayed up under `[heavy / abusive]` queries that previously OOM'd a
  coordinator.

> Lead with the MTTR number — it's the observability story and it's the one that
> lands hardest for this company.

## What I'd do differently

I'd have instrumented with tracing **from day one** instead of adding it after we
were already firefighting; nearly every hard debugging session before the
rollout would have been minutes instead of hours. I'd also have defined the SLOs
(query latency, freshness) and error budget *before* tuning, because without them
we argued about "fast enough" subjectively for too long.

---

## Likely follow-up questions (and how to handle them)

- **"What happens when a shard is down mid-query?"** Deadline cuts it; response
  is labeled partial; alerting treats partial as a defined state, not a silent
  pass. Tie back to "honest about uncertainty."
- **"How did you bound a runaway query?"** Per-query caps on series/memory/time
  range, enforced at the coordinator, with a clear error to the caller.
- **"Why eventual/bounded-staleness consistency?"** It matches the workload:
  monitoring tolerates seconds of staleness, and the availability and latency you
  gain are worth far more than strict consistency for this use case.
- **"How did tracing actually cut MTTR?"** Concrete example: a p99 regression
  that one labeled trace localized to `[a single slow shard / a GC pause / a
  lock]` in minutes; describe reading the waterfall.
- **"How did you keep tenants fair?"** Per-tenant limits + `[scheduling /
  isolation]` so one heavy tenant can't monopolize coordinators.

## The Dash0 connection (steer here on purpose)

This is **Dash0's control plane and its core value prop in one story**: real
PromQL execution over distributed storage (their query model), plus distributed
tracing as the thing that cuts MTTR (their headline benefit, and what Agent0
automates). When you reach the tracing-MTTR result, pivot: *"that manual
root-cause-via-traces work is exactly what Agent0 is automating, right?"* — it
shows you understand not just the product but where it's heading. Good question
to ask: *"How do you keep PromQL latency bounded at high fan-out, and where does
partial-result handling surface to the user?"*

See: [../alerting/promql-checks.md](../alerting/promql-checks.md),
[../distributed-tracing/errors-and-root-cause.md](../distributed-tracing/errors-and-root-cause.md),
[../agent0/root-cause-and-code.md](../agent0/root-cause-and-code.md).
