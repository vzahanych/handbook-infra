# Project 1 — High-throughput telemetry ingestion pipeline (Go)

> **Dimension:** data-plane performance — Go concurrency, backpressure, memory/GC
> discipline, profiling. **Map this onto:** any Go service you built that ingested
> or processed a high-volume stream (events, metrics, logs, messages) under
> latency or cost pressure. Replace `[bracketed]` values with real numbers.

---

## The 30-second version (lead with this)

> "I owned a Go service that ingested `[~X million]` events per second of
> telemetry from `[N]` upstreams, batched and aggregated it, and forwarded it to
> storage. The hard part wasn't the happy path — it was staying alive when a
> downstream slowed down or one tenant blew up cardinality. I redesigned it
> around explicit backpressure and a zero-allocation hot path, which cut p99
> ingest latency from `[A ms]` to `[B ms]` and dropped memory `[C%]`, and it
> stopped falling over during downstream incidents."

Then walk the layers below as they ask.

---

## Context

The system was the ingestion tier of `[a telemetry / events platform]`: a Go
service receiving `[OTLP / a custom protocol]` over gRPC, doing in-flight
batching and aggregation, and writing to `[a time-series store / Kafka /
object storage]`. It sat on the critical path for every customer's data, so an
outage here meant blind customers, and over-provisioning here was a direct line
on the cloud bill — both the reliability and the cost story live in this tier.

## The problem / constraint

A single ingestion node has to absorb a bursty, unbounded inbound stream while
its downstream has finite and variable throughput, which is the classic
producer-faster-than-consumer problem at the heart of every data pipeline. Two
failure modes dominated: when the downstream slowed, the naive design buffered
without limit and the process was **OOM-killed**; and when one tenant emitted
high-cardinality data, it starved everyone else. The constraint was to bound
memory and protect tail latency *without* silently losing data we'd promised to
keep.

## My role and the key decisions

I owned the redesign end to end. The decisions worth narrating, each as a
trade-off rather than a fact:

- **Explicit backpressure over unbounded buffering.** I replaced the
  "accept everything, queue it" path with bounded channels and a worker pool, so
  pressure from the downstream propagates back to the gRPC layer, which then
  signals the client to slow down (`RESOURCE_EXHAUSTED`) instead of the node
  dying. The trade-off I can defend: pushing backpressure to the client is less
  convenient for them but is the only honest option when the alternative is data
  loss or a crash.
- **Bounded queues with a deliberate drop policy.** Where buffering was needed I
  used fixed-size ring buffers, and made the overflow behavior an explicit
  decision — drop lowest-priority signal first and emit a metric — rather than
  an accident. Observability systems must be honest about their own loss.
- **Zero-allocation hot path.** The per-event path allocated on every message,
  so GC pressure dominated CPU under load. I used `sync.Pool` for buffers,
  reused decode scratch space, and switched hot structs to value semantics to
  keep them off the heap. I found these with `pprof` (alloc and CPU profiles),
  not by guessing — I can talk through reading a flame graph.
- **Sharding by series/tenant to contain blast radius.** I partitioned work by a
  hash of the series key so one hot tenant saturates its own shard and worker,
  not the whole node — a bulkhead. The trade-off is uneven shard load, which I
  mitigated with `[consistent hashing / a rebalancing step]`.
- **Cardinality limits and tail-based sampling.** To control both cost and the
  cardinality-explosion failure mode, I added per-tenant cardinality caps and
  `[tail-based sampling]`, keeping the interesting (errored/slow) data and
  shedding the rest. This is a direct cost-vs-fidelity lever.

## Impact

- p99 ingest latency `[A ms] → [B ms]`; p99.9 stopped spiking during downstream
  slowdowns.
- Memory footprint down `[C%]`; the OOM-kill class of incident went to zero.
- Throughput per node `[X → Y]`, which cut the fleet size and `[$Z / month]`.
- `[An incident]` that previously took the tier down became a graceful
  slowdown with backpressure and a clear signal to operators.

> Keep at least one of these as a hard number you can stand behind. If you only
> have one real metric, lead with it and present the rest qualitatively.

## What I'd do differently

I'd introduce the cardinality limits and sampling *earlier* — I treated them as a
cost optimization after the fact, but they're really a core reliability control,
and adding them late meant a painful migration of already-stored data. I'd also
invest sooner in load tests that replay *real* production traffic shapes, because
the synthetic uniform load I started with hid exactly the bursty, skewed
patterns that caused the production incidents.

---

## Likely follow-up questions (and how to handle them)

- **"How did backpressure actually propagate to the client?"** Bounded channel
  full → worker pool can't accept → gRPC handler returns `RESOURCE_EXHAUSTED` /
  blocks the stream → client's exporter retries with backoff. Mention OTLP
  exporters have retry/queue semantics for exactly this.
- **"How did you pick the queue sizes / worker counts?"** Measured, not guessed:
  sized to keep memory bounded at the worst-case message size × depth, tuned
  worker count to downstream concurrency, validated under load with pprof.
- **"What did you drop, and how did you stay honest about it?"** Explicit drop
  policy + a counter metric + it showing in the customer's own data-quality view.
  Never drop silently.
- **"Why Go here?"** Goroutines/channels make the concurrent pipeline natural;
  the cost is GC, which is why the allocation discipline mattered. Honest about
  the trade-off rather than evangelizing.

## The Dash0 connection (steer here on purpose)

This is **Dash0's data plane**. The OpenTelemetry Collector solves exactly these
problems — receivers, batching/memory-limiter processors, backpressure, tail
sampling — and Dash0's volume-based pricing makes the cardinality/sampling levers
a *product* concern, not just an internal optimization. A natural question to ask
them: *"Where do you make the sampling decision — at the Collector edge or after
ingest — and how do you keep that honest for customers who pay by volume?"* That
shows you've lived the trade-off they sell into.

See: [../opentelemetry-native/collector-and-sdks.md](../opentelemetry-native/collector-and-sdks.md),
[../pricing-and-cost/volume-based-model.md](../pricing-and-cost/volume-based-model.md).
