# Dash0 Discovery Call — project walkthroughs

This folder holds two project walkthroughs to prepare for the Dash0 Discovery
Call (backend / Go). They are **scaffolds, not biography**: realistic, deep
narratives in advanced observability-adjacent domains, with `[bracketed]`
placeholders where your real numbers go. Map them onto work you have actually
done, replace the placeholders with true figures, and drop anything you cannot
speak to honestly. Never present an invented metric as fact in the interview.

## Why these two domains

The two are chosen to be **adjacent to Dash0's own problem space** so every
technical decision doubles as a signal that you understand observability, and to
cover **two different dimensions** of engineering so you don't tell the same
story twice:

- [project-1-telemetry-ingestion-pipeline.md](project-1-telemetry-ingestion-pipeline.md)
  — **data-plane performance**: a high-throughput Go ingestion pipeline.
  Showcases Go concurrency, backpressure, memory/GC discipline, and profiling.
- [project-2-distributed-query-platform.md](project-2-distributed-query-platform.md)
  — **distributed-systems correctness and reliability**: a sharded, multi-tenant
  time-series query backend. Showcases sharding, consistency trade-offs, SLOs,
  and a concrete incident/MTTR win.

## How to deliver a walkthrough (2–3 minutes each)

Lead with the shape, not the chronology. The structure each file follows:

1. **Context** — one sentence on the system and why it mattered (scale, money,
   users). Enough for the listener to care; no more.
2. **Problem / constraint** — the specific hard thing. This is the hook.
3. **Your role and decisions** — what *you* did, the options you weighed, and
   *why* you chose what you chose. Trade-offs are where senior signal lives.
4. **Impact** — a number. Latency, throughput, cost, MTTR, incidents avoided.
5. **What you'd do differently** — shows reflection and honesty.

Then stop and let them dig. Each file ends with **likely follow-up questions**
and a **Dash0 connection** paragraph so you can steer the conversation toward
their domain on purpose.

## Mapping to your real experience

Before the call, for each walkthrough, write down in the margin: which real
project this maps to, the one true metric you'll quote, and the one decision you
are most ready to defend under questioning. If a placeholder has no honest real
value behind it, cut that sentence rather than guess.

---

## References

- Dash0 product handbook: [../fundamentals.md](../fundamentals.md)
- Code RED podcast (Dash0) and Dash0 docs — listen/skim before the call.
